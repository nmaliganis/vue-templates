type Sort = {
  label: string | null;
  order: "asc" | "desc";
};

export { Sort };
